package com.magicsquare;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Home extends AppCompatActivity {
    TextView newgame, cont;
    SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        newgame=findViewById(R.id.activity_home_newgame);
        cont=findViewById(R.id.activity_home_continue);
        sp=getSharedPreferences("MyDatabase",MODE_PRIVATE);
       final  String s=sp.getString("level",null);
        newgame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Home.this,Level1Puzzle1.class));
                SharedPreferences.Editor editor=sp.edit();
                editor.putString("level","0");
                editor.commit();
            }
        });

        cont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(s.equals("2")){
                    startActivity(new Intent(Home.this,Level1Puzzle2.class));
                }
                else if(s.equals("3")){
                    startActivity(new Intent(Home.this,Level1Puzzle3.class));
                }
                else if(s.equals("4")){
                    startActivity(new Intent(Home.this,Level2Puzzle1.class));
                }
                else{
                    startActivity(new Intent(Home.this,Level1Puzzle1.class));
                }
            }
        });

    }
}
