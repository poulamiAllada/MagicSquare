package com.magicsquare;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Level1Puzzle1 extends AppCompatActivity {
    EditText et1,et2,et3,et4,et5,et6,et7,et8,et9;
    Button check;
    TextView hints,trails;
    int hint=3,trail=5;
    SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level1puzzle1);
        et1= findViewById(R.id.activity_level1puzzle1_et1);
        et2= findViewById(R.id.activity_level1puzzle1_et2);
        et3= findViewById(R.id.activity_level1puzzle1_et3);
        et4= findViewById(R.id.activity_level1puzzle1_et4);
        et5= findViewById(R.id.activity_level1puzzle1_et5);
        et6= findViewById(R.id.activity_level1puzzle1_et6);
        et7= findViewById(R.id.activity_level1puzzle1_et7);
        et8= findViewById(R.id.activity_level1puzzle1_et8);
        et9= findViewById(R.id.activity_level1puzzle1_et9);
        check=findViewById(R.id.activity_level1puzzle1_check_btn);
        hints=findViewById(R.id.activity_level1puzzle1_hints);
        trails=findViewById(R.id.activity_level1puzzle1_trails);
        et1.setInputType(InputType.TYPE_CLASS_NUMBER);
        et1.setKeyListener(DigitsKeyListener.getInstance("0123456789"));
        et1.setSingleLine(true);
        sp=getSharedPreferences("MyDatabase",MODE_PRIVATE);
        hints.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(hint!=0){
                    hint= hint-1;
                    hints.setText("hints : "+hint);

                    if(et1.getText().toString().isEmpty()){
                        et1.setText("3");
                        et1.setEnabled(false);
                    }
                    else if(et2.getText().toString().isEmpty()){
                        et2.setText("3");
                        et2.setEnabled(false);
                    }
                    else if(et5.getText().toString().isEmpty()){
                        et5.setText("1");
                        et5.setEnabled(false);
                    }
                    else if(et3.getText().toString().isEmpty()){
                        et3.setText("1");
                        et3.setEnabled(false);
                    }

                    else if(et6.getText().toString().isEmpty()){
                        et6.setText("1");
                        et6.setEnabled(false);
                    }
                    else if(et7.getText().toString().isEmpty()){
                        et7.setText("1");
                        et7.setEnabled(false);
                    }

                    else if(et4.getText().toString().isEmpty()){
                        et4.setText("4");
                        et4.setEnabled(false);
                    }
                    else if(et8.getText().toString().isEmpty()){
                        et8.setText("2");
                        et8.setEnabled(false);
                    }
                    if(et9.getText().toString().isEmpty()){
                        et9.setText("3");
                        et9.setEnabled(false);
                    }

                }
                else{
                    Toast.makeText(Level1Puzzle1.this, "Hints completed", Toast.LENGTH_SHORT).show();
                }

            }
        });

        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(et1.getText().toString().isEmpty() || et2.getText().toString().isEmpty()||et3.getText().toString().isEmpty() || et4.getText().toString().isEmpty()||et6.getText().toString().isEmpty() || et7.getText().toString().isEmpty() ||
                        et8.getText().toString().isEmpty()|| et9.getText().toString().isEmpty()){
                    Toast.makeText(Level1Puzzle1.this, "please fill all fields", Toast.LENGTH_SHORT).show();
                }
                else {
                    // calculate values
                    int ar[][]=new int[3][3];
                    ar[0][0]=Integer.parseInt(et1.getText().toString());
                    ar[0][1]=Integer.parseInt(et2.getText().toString());
                    ar[0][2]=Integer.parseInt(et3.getText().toString());
                    ar[1][0]=Integer.parseInt(et4.getText().toString());
                    ar[1][1]=Integer.parseInt(et5.getText().toString());
                    ar[1][2]=Integer.parseInt(et6.getText().toString());
                    ar[2][0]=Integer.parseInt(et7.getText().toString());
                    ar[2][1]=Integer.parseInt(et8.getText().toString());
                    ar[2][2]=Integer.parseInt(et9.getText().toString());
                    int ar1[][]= new int[2][3];
                    ar1[0][0]= ar[0][0]+(ar[0][1]*ar[0][2]);
                    ar1[0][1]= ar[1][0]+ar[1][1]+ar[1][2];
                    ar1[0][2]= ar[2][0]+ar[2][1]+ar[2][2];

                    ar1[1][0]= (ar[0][0]+ar[1][0])-ar[2][0];
                    ar1[1][1]= ar[0][1]*ar[1][1]*ar[2][1];
                    ar1[1][2]= (ar[0][2]+ar[1][2])*ar[2][2];
                    int count=0;
                    for(int i=0;i<2;i++){
                        for(int j=0;j<3;j++){
                            if(ar1[i][j]== 6){
                                count++;
                            }
                        }
                    }

                    if(count == 6){
                        // custom dialog
                        final Dialog dialog = new Dialog(Level1Puzzle1.this);
                        dialog.setContentView(R.layout.puzzle_completed_popup);
                        Button nextLevel = (Button) dialog.findViewById(R.id.activity_level1puzzle1popup_btn2);

                        // if button is clicked, go to next level
                        nextLevel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                                startActivity(new Intent(Level1Puzzle1.this,Level1Puzzle2.class));
                                SharedPreferences.Editor editor=sp.edit();
                                editor.putString("level","2");
                                editor.commit();
                            }
                        });
                        dialog.show();
                        Toast.makeText(Level1Puzzle1.this, "Correct", Toast.LENGTH_SHORT).show();
                    }
                    else{
                       // Toast.makeText(Level1Puzzle1.this, "wrong answer", Toast.LENGTH_SHORT).show();
                        if(trail > 0){
                            trail=trail-1;
                            trails.setText("Trails : "+trail);
                        }
                        else{
                            Toast.makeText(Level1Puzzle1.this, "Gameover", Toast.LENGTH_SHORT).show();

                            // custom dialog
                            final Dialog dialog = new Dialog(Level1Puzzle1.this);
                            dialog.setContentView(R.layout.gameover);
                            Button solve = dialog.findViewById(R.id.activity_level1puzzle1_gameover);
                            solve.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {

                                    dialog.dismiss();
                                    et1.setText("3");
                                    et1.setEnabled(false);
                                    et2.setText("3");
                                    et2.setEnabled(false);
                                    et3.setText("1");
                                    et3.setEnabled(false);
                                    et4.setText("4");
                                    et4.setEnabled(false);
                                    et5.setText("1");
                                    et5.setEnabled(false);
                                    et6.setText("1");
                                    et6.setEnabled(false);
                                    et7.setText("1");
                                    et7.setEnabled(false);
                                    et8.setText("2");
                                    et8.setEnabled(false);
                                    et9.setText("3");
                                    et9.setEnabled(false);

                                }
                            });
                            dialog.show();
                        }
                    }

                }

            }
        });

    }


}
